function drawTriangle(triangleSize) {
   // Outer loop iterates from 0 to triangleSize-1 to control the height of the triangle
   for (let i=0; i<triangleSize; i++){
      let triangle = ''; // Initialize an empty string to store each row of the triangle
      // Inner loop iterates from 0 to i to control the number of '*' characters in each row
      for (let j=0; j<=i; j++){
         triangle += '*'; // Append a '*' to the triangle string for each iteration
      }
      console.log(triangle); // Print the current row of the triangle to the console
   }
}

console.log("Testing drawTriangle()...");

// TODO: Test drawTriangle() with different arguments
drawTriangle(4); // Example usage: draws a triangle with height 4

// Do NOT remove the following line
export default drawTriangle;

