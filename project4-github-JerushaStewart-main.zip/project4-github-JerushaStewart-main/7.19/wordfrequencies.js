function calcWordFrequencies(words) {
    // Split the input string into an array of words
    let wordArray = words.split(" ");
    
    // Create a Map to store word frequencies
    let frequencyMap = new Map();

    // Iterate through each word in wordArray
    wordArray.forEach(word => {
        // Convert each word to lowercase to normalize the frequency count
        let lowerCaseWord = word.toLowerCase();
        
        // Check if the word already exists in the frequencyMap
        if (frequencyMap.has(lowerCaseWord)) {
            // Increment the count if the word exists
            frequencyMap.set(lowerCaseWord, frequencyMap.get(lowerCaseWord) + 1);
        } else {
            // Initialize the count to 1 if the word does not exist
            frequencyMap.set(lowerCaseWord, 1);
        }
    });

    // Function to iterate over the frequencyMap and print word frequencies
    function iterateMap(map) {
        map.forEach((count, word) => {
            console.log(`${word} ${count}`);
        });
    }
 
    // Call iterateMap to print the word frequencies
    iterateMap(frequencyMap);
}

console.log("Testing calcWordFrequencies()...");
calcWordFrequencies("hey hi Mark hi mark");

// Do NOT remove the following line:
export default calcWordFrequencies;
