### `printSum`
The `printSum` function takes two arguments `x` and `y`, checks if they are numbers using `isNaN()` and `parseFloat()`, and then either prints their sum if both are numbers or specific error messages if either or both are not numbers.

### `trianglePerimeter`
The `trianglePerimeter` function calculates the perimeter of a triangle given the coordinates of its three vertices `(x1, y1)`, `(x2, y2)`, and `(x3, y3)`. It uses the `distance` function to compute the lengths of the triangle's sides and returns the sum of these lengths.

### `triangleArea`
The `triangleArea` function computes the area of a triangle using the determinant formula based on the coordinates of its vertices `(x1, y1)`, `(x2, y2)`, and `(x3, y3)`. It returns the absolute value of the determinant divided by 2.

### `calcWordFrequencies`
The `calcWordFrequencies` function takes a string `words`, splits it into an array of words, and calculates the frequency of each word using a `Map`. It prints each word and its frequency using a helper function `iterateMap`.

### `sortEvens`
The `sortEvens` function filters even numbers from an array `numArray`, sorts them in ascending order using `Array.prototype.sort()`, and returns the sorted array of even numbers.

### `drawTriangle`
The `drawTriangle` function prints a triangle made of asterisks (`*`) based on the specified `triangleSize`. It uses nested loops to generate and print each row of the triangle.

### `game` 
The `game` object simulates a game state with properties like `lives` and `coins`, and methods to manipulate these properties (`points`, `playerDies`, `newGame`). It calculates points based on coins, decreases lives when the player dies, and allows resetting the game state.
