function printSum(x, y) {
   // Check if both x and y are not numbers
   if (isNaN(parseFloat(y)) && isNaN(parseFloat(x))) {
      console.log("'" + x + "'" + " and " + "'" + y + "'"  + " are not numbers.")
   }
   // Check if x is not a number
   else if (isNaN(parseFloat(x))){
      console.log( "'" + x + "'"+ " is not a number.")
   }
   // Check if y is not a number
   else if (isNaN(parseFloat(y))){
      console.log("'" + y + "'" + " is not a number.")
   }
   // If both x and y are numbers, calculate and print their sum
   else if (!isNaN(parseFloat(y)) && !isNaN(parseFloat(x))) {
      console.log("Sum is " + (x+y) + ".")
   }
}

console.log("Testing printSum()...");

// Test cases
printSum(3, 6);            // Output: Sum is 9.
printSum(3.5, 6.1);        // Output: Sum is 9.6.
printSum("hello", 6);      // Output: 'hello' is not a number.
printSum(10, "hi");        // Output: 'hi' is not a number.
printSum("hello", "hi");   // Output: 'hello' and 'hi' are not numbers.

// Do NOT remove the following line
export default printSum;
