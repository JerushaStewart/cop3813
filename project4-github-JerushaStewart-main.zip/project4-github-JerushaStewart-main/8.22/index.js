//In this lab, you will write three JavaScript functions 
//to generate a bar graph of letter grades from a distribution of scores, as shown in the image below.

function parseScores(scoresString) {
return scoresString.split(" ").map(Number);
}

function buildDistributionArray(scoresArray) {
   let newer=[0,0,0,0,0];

//(90 and above = A, 80-89 = B, 70-79 = C, 60-69 = D, 59 and below = F)
   for (let i = 0; i < scoresArray.length; i++) {
      if (scoresArray[i] >= 90) {
         newer[0]++; // A
      } else if (scoresArray[i] >= 80) {
         newer[1]++; // B
      } else if (scoresArray[i] >= 70) {
         newer[2]++; // C
      } else if (scoresArray[i] >= 60) {
         newer[3]++; // D
      } else {
         newer[4]++; // F
      }
   }

 return newer
}

function setTableContent(userInput) {
   let distribution = parseScores(userInput);
   let nuw=buildDistributionArray(distribution);


   const doc= document.getElementById('first-row');
   let newContent ='' ;
   nuw.forEach((count, index) => {
      let barHeight = count * 10; 
      newContent += `<td><div style="height:${barHeight}px" class="bar${index}"></div></td>`;
   });

   doc.innerHTML=newContent;

   const third = document.getElementById('third-row');
   let newThird = `<td>${nuw[0]}</td> <td>${nuw[1]}</td> <td>${nuw[2]}</td> <td>${nuw[3]}</td> <td>${nuw[4]}</td>`
   third.innerHTML=newThird;
}

// TODO: Change the arguments for testing purposes
setTableContent("45 78 98 83 86 99 90 59");
