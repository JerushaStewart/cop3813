function sortEvens(numArray) {
    let newarray = []; // Initialize an empty array to store even numbers

    // Loop through each element in numArray
    for(let i=0; i<numArray.length; i++){
        // Check if the current number is even (remainder when divided by 2 is 0)
        if ((numArray[i] % 2) === 0){
            newarray.push(numArray[i]); // Push the even number to newarray
        }
    }

    // Sort newarray in ascending order using a custom compare function
    newarray.sort(function (a, b) {
        return a - b; // Sort in ascending order; use `b - a` for descending order
    });

    return newarray; // Return the sorted array of even numbers
}

console.log("Testing sortEvens()...");
let nums = [4, 2, 9, 1, 8];
let evenNums = sortEvens(nums);
console.log(evenNums); // Output: [2, 4, 8]

// Do NOT remove the following line:
export default sortEvens;
