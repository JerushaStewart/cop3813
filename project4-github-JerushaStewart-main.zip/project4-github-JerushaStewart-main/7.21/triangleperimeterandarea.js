function square(z){
   return(z*z);
}

function distance(x1, y1, x2, y2) {
    // Calculate the distance between two points using the Pythagorean theorem
    return Math.sqrt(square(x2 - x1) + square(y2 - y1));
}

function trianglePerimeter(x1, y1, x2, y2, x3, y3) {
    // Calculate the perimeter of the triangle by summing the lengths of its sides
    let side1 = distance(x1, y1, x2, y2);
    let side2 = distance(x2, y2, x3, y3);
    let side3 = distance(x3, y3, x1, y1);
    
    return side1 + side2 + side3;
}

function triangleArea(x1, y1, x2, y2, x3, y3) {
    // Calculate the area of the triangle using the determinant formula
    return Math.abs((x1*(y2-y3)) + (x2*(y3-y1)) + (x3*(y1 - y2))) / 2;
}

console.log("Testing trianglePerimeter()...");
let perimeter = trianglePerimeter(1, 0, 2, 4, 4, 3);
console.log("Perimeter = " + perimeter);

console.log("Testing triangleArea()...");
let area = triangleArea(1, 0, 2, 4, 4, 3);
console.log("Area = " + area);

// Do NOT remove the following line:
export { trianglePerimeter, triangleArea };
